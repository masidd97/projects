const mongoose = require('mongoose');


const notesSchema = new mongoose.Schema({
    topic:{
        type:String,
        required:true
    },
    reference:{
        type:String,
        required:true,
        
    },
    outline:{
        type:String,
        required:true
    },
    date:{
        type:String,
        required:true
    },
    content:{
        type:String,
        required:true
    },
    summary:{
        type:String,
        required:true
    },
},
{
    timestamps:true
});
const Note = mongoose.model('Note',notesSchema);
module.exports=Note;