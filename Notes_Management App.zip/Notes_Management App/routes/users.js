
const express = require('express');
const router = express.Router();
const passport = require('passport');
const usersController = require('../controllers/users_controller');
const User= require('../models/user');

router.get('/profile',usersController.profile);
router.get('/sign-up',usersController.signUp);
router.get('/sign-in',usersController.signIn);
router.post('/create',usersController.create);

//use [passport ] as a middleware to authenticate
router.post('/create-session',passport.authenticate(
    'local',
    {failureRedirect:'/users/sign-in'}
),usersController.createSession);
router.get('/sign-out',usersController.destroySession);
router.get('/auth/google',passport.authenticate('google',{scope:['profile','email']}));
router.get('/auth/google/callback',passport.authenticate('google',{failureRedirect:'/users/sign-in'}),usersController.createSession);
router.get('/forgot', function(req, res) {
    res.render('forgot', {
          title:"forgot Password" });
  });
 router.post('/forgot',usersController.forgot);
 router.get('/reset/:token', function(req, res) {
    // User.findOne({ resetPasswordToken: req.params.token, resetPasswordExpires: { $gt: Date.now() } }, function(err, user) {
    //   if (!user) {
    //     req.flash('error', 'Password reset token is invalid or has expired.');
    //     return res.redirect('/');
    //   }
      res.render('reset', {title:"Reset Password",token: req.params.token});
    });
 
 router.post('/reset/:token',usersController.reset);
module.exports = router;