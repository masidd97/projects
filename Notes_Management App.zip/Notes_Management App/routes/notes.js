const express = require('express');
const router = express.Router();
const passport = require('passport');
const noteController = require('../controllers/notes_controller');
const Note= require('../models/note');


router.get('/add-note',noteController.addNote);
router.post('/create-note',noteController.createNote);

module.exports = router ;