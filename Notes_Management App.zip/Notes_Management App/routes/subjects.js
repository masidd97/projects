const express = require('express');
const router = express.Router();
const passport = require('passport');
const subjectController = require('../controllers/subject_controller');
const Subject= require('../models/subject');


router.get('/add-subject',subjectController.addSubject);
router.post('/create-subject',subjectController.createSubject);

module.exports = router ;