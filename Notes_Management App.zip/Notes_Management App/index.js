const express = require('express');
const app = express();


const port = 8000;
const cookieParser = require('cookie-parser');
const path = require('path');
var bodyParser = require('body-parser');
const expressLayouts = require('express-ejs-layouts');
const sassMiddleware = require('node-sass-middleware');
const db = require('./config/mongoose');
const passport = require('passport');
const passportLocal = require('./config/passport-local-strategy');
const passportGoogle = require('./config/passport-google-oauth-strategy');
const flash = require('connect-flash');
const customMware =require ('./config/middleware');
const session = require('express-session');
const MongoStore = require('connect-mongo')(session);
app.use(cookieParser());

app.use(express.urlencoded());
app.use(bodyParser.urlencoded({ extended: false }));
app.use(expressLayouts);


//setting up view engine
app.set('view engine','ejs');
app.set('views','./views');




app.use(sassMiddleware({
    src:'assets/scss',
    dest:'assets/css',
    debug:true,
    outputStyle:'extended',
    prefix:'/css'
}));

app.use(express.static('./assets'));

//extract style and script 
app.set('layout extractStyles',true);
app.set('layout extractScripts',true);

//mongo store is used to store the session cookie in the db


app.use(session({
    name:"MyNote",
    //TODO change the secret before deployment in production mode
secret:'blahsomething',
saveUninitialized:false,
resave:false,
cookie:{
    maxAge:(1000*60*100)
},
store:new MongoStore({
mongooseConnection:db,
autoRemove:'disabled'
},
function(err)
{
    console.log(err || 'connect mongodb setup ok');
}
)
}));

app.use(passport.initialize());
app.use(passport.session());
app.use(passport.setAuthenticatedUser);

app.use(flash());
app.use(customMware.setFlash);

//use express router
app.use('/',require('./routes'));

app.listen(port ,function(err){
    if(err){
        console.log(`Error in running the server : ${err}`);
    }
    console.log(`Server is running on port : ${port}`);
});