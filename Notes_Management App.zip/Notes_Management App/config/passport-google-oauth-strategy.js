const passport = require('passport');
const googleStrategy = require('passport-google-oauth').OAuth2Strategy;
const crypto = require('crypto');



//tell passport to use a new strategy for google login
passport.use(new googleStrategy({
clientID:'208186934884-p41drq690aoof6hmb6t2o9enoctqj8vi.apps.googleusercontent.com',
clientSecret:'ZhDgTpuAHY4E5owdeLJH0-IR',
callbackURL:'http://localhost:8000/users/auth/google'
},function(err){
    console.log(err);
}));
module.exports = passport;
