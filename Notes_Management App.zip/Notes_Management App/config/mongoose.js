const mongoose = require('mongoose');

mongoose.connect(`mongodb://localhost/thenote_development`);
const db =mongoose.connection;
//if error then print this
db.on('error' , console.error.bind(console , 'error connecting to db'));
//if no error then print this
db.once('open' ,function(){
    console.log('successfully connected to the database::mongoDB');
});

module.exports = db;