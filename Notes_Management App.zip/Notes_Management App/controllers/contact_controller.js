const Contact=require('../models/contact');
const nodemailer = require('nodemailer');
module.exports.message = function(req ,res){
  
    Contact.create({
        name:req.body.name,
        email:req.body.email,
        message:req.body.message
        
    },function(){
        var smtpTransport = nodemailer.createTransport({
            service: 'Gmail', 
            auth: {
              user: 'kng5837@gmail.com',
              pass: 'Salma@17'
            }
          });
     var mailOptions = {
        from: 'kng5837@gmail.com', // sender address
        to: req.body.email, // list of receivers
        subject:'USER MESSAGE ', // Subject line
        text: req.body.message // plaintext body

    };
        smtpTransport.sendMail(mailOptions, function(error, info) {
         if (error) {
             return console.log(error);
         }
         console.log('Message sent: ' + info.response);
     });
    })
return res.redirect('back');
}