const Note= require('../models/note');

const notelist =[
    {
        subject:"eng",
        
        course:"ba"
    }]

module.exports.addNote = function(req ,res){
//     return res.render('add_subject' , {
//         title:"Thenote | subject",
        
//  });

Note.find({},function(err,notelist){
    if(err){
        console.log('error in fetching a task from db');
        return;
      }
      return res.render('add_note',{
        title:"add_note",
        note_list:notelist
     });
});
 }

 module.exports.createNote = async function( req,res){
     console.log(req.body);
     Note.create({
          topic : req.body.topic,
          reference : req.body.reference,
          outline : req.body.outline,
          date : req.body.date,
          content : req.body.content,
          summary : req.body.summary
          });
  
         
  
          if(req.xhr){
            return res.status(200).json({
              
                data:{
                  subject:subject
                },
                message: "New note Added"
              
            })
          }
          req.flash('success','New note Added !');
          return res.redirect('back');
    
   }