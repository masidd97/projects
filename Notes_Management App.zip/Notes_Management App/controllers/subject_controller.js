const Subject= require('../models/subject');

const subjectlist =[
    {
        subject:"eng",
        
        course:"ba"
    }]

module.exports.addSubject = function(req ,res){
//     return res.render('add_subject' , {
//         title:"Thenote | subject",
        
//  });

Subject.find({},function(err,subjectlist){
    if(err){
        console.log('error in fetching a task from db');
        return;
      }
      return res.render('add_subject',{
        title:"add_subject",
        subject_list:subjectlist
     });
});
 }

 module.exports.createSubject = async function( req,res){
     console.log(req.body);
     Subject.create({
          subject : req.body.subject,
          course : req.body.course
          });
  
         
  
          if(req.xhr){
            return res.status(200).json({
              
                data:{
                  subject:subject
                },
                message: "subject Added"
              
            })
          }
          req.flash('success','Subject Added !');
          return res.redirect('back');
    
   }