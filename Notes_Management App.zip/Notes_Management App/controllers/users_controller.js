const User= require('../models/user');
const fs = require('fs');
const path= require('path');
const crypto = require('crypto');
var async = require("async");
var nodemailer = require("nodemailer");



module.exports.profile = function(req ,res){
    return res.render('user_profile' , {
        title:"Thenote | profile",
        
});
}




//forgot password

module.exports.forgot = function(req,res,next){
    async.waterfall([
       function(done) {
         crypto.randomBytes(20, function(err, buf) {
           var token = buf.toString('hex');
           done(err, token);
         });
       },
       function(token, done) {
         User.findOne({ email: req.body.email }, function(err, user) {
           if (!user) {
             req.flash('error', 'No account with that email address exists.');
             return res.redirect('back');
           }
   
           user.resetPasswordToken = token;
           user.resetPasswordExpires = Date.now() + 3600000; // 1 hour
   
           user.save(function(err) {
             done(err, token, user);
           });
         });
       },
       function(token, user, done) {
         var smtpTransport = nodemailer.createTransport({
           service: 'Gmail', 
           auth: {
             user: 'nazreennazia12@gmail.com',
             pass: 'NAZ12021997'
           }
         });
         var mailOptions = {
           to: user.email,
           from: 'nazreennazia12@gmail.com',
           subject: 'Node.js Password Reset',
           text: 'You are receiving this because you (or someone else) have requested the reset of the password for your account.\n\n' +
             'Please click on the following link, or paste this into your browser to complete the process:\n\n' +
             'http://' + req.headers.host + '/users/reset/' + token + '\n\n' +
             'If you did not request this, please ignore this email and your password will remain unchanged.\n'
         };
         smtpTransport.sendMail(mailOptions, function(err) {
           console.log('mail sent');
           req.flash('success', 'An e-mail has been sent to ' + user.email + ' with further instructions.');
           done(err, 'done');
         });
       }], function(err) {
          if (err) return next(err);
          res.redirect('back');
        });
 }
 
  //reset password
 
 module.exports.reset = function(req, res)
  {
    async.waterfall([
       function(done) {
         User.findOne({ resetPasswordToken: req.params.token, resetPasswordExpires: { $gt: Date.now() } }, function(err, user) {
          if(err){
             console.log('error while resetting password',err);
             return;
          } 
          console.log(user);
          if (!user)
          {
             req.flash('error', 'Password reset token is invalid or has expired.');
             return res.redirect('/');
           
          }
          
           if(req.body.password === req.body.confirmpassword)
          {
             user.setPassword(req.body.password, function(err) {
                if(err){
                   console.log('error in setting new password',err);
                   return;
                }
                user.password=req.body.password;
               user.resetPasswordToken = undefined;
               user.resetPasswordExpires = undefined;
               user.save();
               req.flash('success', 'Password reset !');
               return res.redirect('/users/sign-in');
             })
           } 
           else 
           {
               req.flash("error", "Passwords do not match.");
               return res.redirect('back');
           }
         });
    
       }
    ]);
 }
 
 
//  module.exports.update = async function(req, res){
    
 
//     if(req.user.id == req.params.id){
 
//         try{
 
//             let user = await User.findById(req.params.id);
//             User.uploadedAvatar(req, res, function(err){
//                 if (err) {console.log('*****Multer Error: ', err)}
                
//                 user.name = req.body.name;
//                 user.email = req.body.email;
 
//                 if (req.file){
//                     if (user.avatar){
//                         fs.unlinkSync(path.join(__dirname, '..', user.avatar));
//                     }
 
 
//                     // this is saving the path of the uploaded file into the avatar field in the user
//                     user.avatar = User.avatarPath + '/' + req.file.filename;
//                 }
//                 user.save();
//                 return res.redirect('back');
//              });
 
//           }catch(err){
//               req.flash('error', err);
//               return res.redirect('back');
//           }
  
  
//       }else{
//           req.flash('error', 'Unauthorized!');
//           return res.status(401).send('Unauthorized');
//       }
//   }
 
 
 //render the sign up page
 module.exports.signUp = function( req,res){
 if(req.isAuthenticated()){
    return res.redirect('/users/profile');
 }
 
    return res.render('user_sign_up', {
       title:"MYNOTE| sign up" 
    });
      
 }
 
 //render the sign in page
 module.exports.signIn = function( req,res){
    if(req.isAuthenticated()){
       return res.redirect('/users/profile');
    }
    return res.render('user_sign_in', {
       title:"MyNOTE | sign in" });
      
 }
 
 
 
 //get the sign up data
 
 module.exports.create = function( req,res){
    if(req.body.password != req.body.confirm_password)
    {
       return res.redirect('back');
    }
    User.findOne({email:req.body.email} ,function(err , user){
       if(err){
          console.log('error in finding user');
          return;
       }
      if(!user){
         User.create(req.body , function(err , req){
          if(err){
             console.log('error in finding user');
             return;
          }
          return res.redirect('/users/sign-in');
         });
      }
 
      else{
       return res.redirect('back');
      }
    });
 }
 
 //get the sign in and create a session
 
 module.exports.createSession = function( req,res){
    req.flash('success','logged in successfully');
    return res.redirect('/subjects/add-subject');
 }
 
 //destroy session 
 module.exports.destroySession = function( req,res){
    req.flash('success','you have logged out successfully !');
    req.logout();
    return res.redirect('/');
 }